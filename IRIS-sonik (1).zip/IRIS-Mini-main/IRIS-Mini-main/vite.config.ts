import { defineConfig } from "vite";

const isProduction = process.env.NODE_ENV === "production";

export default defineConfig({
  logLevel: isProduction ? "silent" : "info",
});
