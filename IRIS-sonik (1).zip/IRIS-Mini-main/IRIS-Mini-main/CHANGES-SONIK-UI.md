# Sonik UI wired into IRIS-Mini

Old React UI removed (`src/client/`). The new UI is the single file `index.html` (Sonik).
It talks to the backend with the same socket.io events as before, plus a few new ones.

## Changed / added files
- `index.html` : new Sonik UI + backend wiring (socket.io).
- `vite.config.ts` : react/tailwind plugins no longer needed.
- `src/server/utils/api-key.ts` : NEW. Saves the Gemini key to `~/.iris-mini-config.json`.
- `src/server/main.ts` : new socket events (below).
- `src/server/agent/iris-voice.ts` : mic mute, voice mute, typed text, friendlier key messages. Voice/Gemini logic untouched.
- `bin/iris-mini.ts` : no more terminal questions for the API key.
- `.env.example` : comment only.

## Socket events
Same as before: `Iris_Connected`, `Iris_Disconnected` (UI -> server); `system_status`, `transcript_chunk`, `turn_complete` (server -> UI).
New: `set_api_key`, `clear_api_key`, `mic_mute`, `voice_mute`, `user_text` (UI -> server); `api_key_status`, `api_key_result` (server -> UI).

## Buttons
- Power: connect / disconnect (starts OFF, like the old Connect button).
- Mic button: mute / unmute your microphone.
- Voice button: mute / unmute the assistant's spoken audio (text replies keep coming).
- Message bar: typed message goes to the live Gemini session.
- Settings > API: key goes to the server, saved, used on next connect. Never stored in the browser.

`react`, `three`, `tailwindcss`, ... are still in package.json (harmless). Remove later with `npm uninstall` if you want.

## Fix: "Cannot GET /" with npm run dev
`main.ts` forced vite-express into production mode, which needs a `dist/` build. It now uses development mode
for `npm run dev` (live, no build) and production mode only when NODE_ENV=production (packaged CLI).
