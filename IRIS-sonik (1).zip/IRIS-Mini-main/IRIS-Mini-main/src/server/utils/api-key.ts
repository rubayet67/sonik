import * as fs from "fs";
import * as os from "os";
import * as path from "path";

/**
 * Gemini API key store.
 *
 * The key is saved in the same file the CLI always used (~/.iris-mini-config.json),
 * so nothing has to be asked in the terminal any more: the UI (Settings -> API)
 * sends the key to the server, the server saves it here and puts it in
 * process.env so the next "Connect" picks it up. The full key is never sent
 * back to the browser, only a masked hint.
 */
const configPath = path.join(os.homedir(), ".iris-mini-config.json");
const DEFAULT_VOICE = "Lyra";

type Config = { apiKey?: string; voice?: string; [k: string]: unknown };

function readConfig(): Config {
  try {
    const raw = JSON.parse(fs.readFileSync(configPath, "utf-8"));
    return raw && typeof raw === "object" && !Array.isArray(raw) ? (raw as Config) : {};
  } catch {
    return {};
  }
}

function writeConfig(cfg: Config): void {
  fs.writeFileSync(configPath, JSON.stringify(cfg, null, 2), { mode: 0o600 });
}

const currentKey = () =>
  (process.env.GOOGLE_API_KEY || process.env.GEMINI_API_KEY || "").trim();

/** Call once at server start: loads the saved key / voice into process.env. */
export function loadSavedConfig(): void {
  const cfg = readConfig();
  if (typeof cfg.apiKey === "string" && cfg.apiKey.trim()) {
    process.env.GOOGLE_API_KEY = cfg.apiKey.trim();
  }
  if (!process.env.IRIS_VOICE && typeof cfg.voice === "string" && cfg.voice.trim()) {
    process.env.IRIS_VOICE = cfg.voice.trim();
  }
}

export type ApiKeyStatus = { has: boolean; hint: string };

export function getApiKeyStatus(): ApiKeyStatus {
  const k = currentKey();
  return { has: k.length > 0, hint: k ? `••••${k.slice(-4)}` : "" };
}

export function saveApiKey(raw: unknown): { ok: true } | { ok: false; error: string } {
  const key = typeof raw === "string" ? raw.trim() : "";
  if (key.length < 10 || key.length > 300 || /\s/.test(key)) {
    return { ok: false, error: "That doesn't look like a full API key. Paste the whole key." };
  }
  try {
    const cfg = readConfig();
    writeConfig({ ...cfg, apiKey: key, voice: cfg.voice || DEFAULT_VOICE });
  } catch (e) {
    return { ok: false, error: `Could not save the key (${e instanceof Error ? e.message : "write error"}).` };
  }
  process.env.GOOGLE_API_KEY = key;
  return { ok: true };
}

export function clearApiKey(): { ok: true } | { ok: false; error: string } {
  try {
    const cfg = readConfig();
    delete cfg.apiKey;
    if (Object.keys(cfg).length > 0) writeConfig(cfg);
    else if (fs.existsSync(configPath)) fs.unlinkSync(configPath);
  } catch (e) {
    return { ok: false, error: `Could not remove the key (${e instanceof Error ? e.message : "write error"}).` };
  }
  delete process.env.GOOGLE_API_KEY;
  delete process.env.GEMINI_API_KEY;
  return { ok: true };
}
