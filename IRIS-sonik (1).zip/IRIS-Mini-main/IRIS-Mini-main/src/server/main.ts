import express from "express";
import http from "http";
import { Server } from "socket.io";
import ViteExpress from "vite-express";
import {
  sendUserText,
  setMicMuted,
  setVoiceMuted,
  startIrisVoice,
  stopIrisVoice,
} from "./agent/iris-voice.js";
import { clearApiKey, getApiKeyStatus, loadSavedConfig, saveApiKey } from "./utils/api-key.js";
import { getAvailablePort } from "./lib/port-picker.js";
import path from "path";
import { fileURLToPath } from "url";

if (process.env.NODE_ENV === "production") {
  const originalStdout = process.stdout.write.bind(process.stdout);
  process.stdout.write = ((chunk: any, encoding?: any, callback?: any): boolean => {
    if (typeof chunk === "string" && chunk.includes("[vite-express]")) return true;
    return originalStdout(chunk, encoding, callback);
  }) as any;

  const originalStderr = process.stderr.write.bind(process.stderr);
  process.stderr.write = ((chunk: any, encoding?: any, callback?: any): boolean => {
    if (typeof chunk === "string" && (chunk.includes("DEP0205") || chunk.includes("DeprecationWarning"))) {
      return true;
    }
    return originalStderr(chunk, encoding, callback);
  }) as any;

  process.on("warning", (warning) => {
    if (warning.name === "DeprecationWarning") return;
  });
}

// Saved Gemini key / voice (set from the UI) -> process.env, before anything connects.
loadSavedConfig();

const app = express();
const server = http.createServer(app);

// "npm run dev" -> serve index.html live through Vite (no build needed). Packaged CLI -> serve dist/.
ViteExpress.config({ mode: process.env.NODE_ENV === "production" ? "production" : "development" });

const io = new Server(server, {
  cors: {
    origin: "*",
  },
});

/** The key can only be changed from the computer IRIS runs on (open http://localhost:<port>). */
const isLocalSocket = (address: string | undefined) =>
  address === "::1" || address === "127.0.0.1" || address === "::ffff:127.0.0.1";

io.on("connection", (socket) => {
  socket.emit("api_key_status", getApiKeyStatus());

  socket.on("set_api_key", (key: unknown) => {
    if (!isLocalSocket(socket.handshake.address)) {
      socket.emit("api_key_result", { ok: false, error: "The key can only be changed from this computer (use http://localhost)." });
      return;
    }
    const r = saveApiKey(key);
    socket.emit("api_key_result", r);
    if (r.ok) io.emit("api_key_status", getApiKeyStatus());
  });

  socket.on("clear_api_key", () => {
    if (!isLocalSocket(socket.handshake.address)) {
      socket.emit("api_key_result", { ok: false, error: "The key can only be changed from this computer (use http://localhost)." });
      return;
    }
    const r = clearApiKey();
    socket.emit("api_key_result", r);
    if (r.ok) io.emit("api_key_status", getApiKeyStatus());
  });

  socket.on("mic_mute", (muted: unknown) => setMicMuted(muted === true));
  socket.on("voice_mute", (muted: unknown) => setVoiceMuted(muted === true));

  socket.on("user_text", (text: unknown) => {
    const r = sendUserText(typeof text === "string" ? text : "");
    if (!r.ok) socket.emit("system_status", `[IRIS] ${r.error}`);
  });

  socket.on("Iris_Connected", (msg) => {
    startIrisVoice(io);
  });

  socket.on("Iris_Disconnected", (msg) => {
    stopIrisVoice(io);
  });

  socket.on("disconnect", () => {
    stopIrisVoice(io);
  });
});

const startServer = async () => {
  const port = await getAvailablePort(6753, 8769);

  server.listen(port, () => {
    console.clear();
    console.clear();

    const banner = `
\x1b[32m
 ██╗██████╗ ██╗███████╗   ███╗   ███╗██╗███╗   ██╗██╗
 ██║██╔══██╗██║██╔════╝   ████╗ ████║██║████╗  ██║██║
 ██║██████╔╝██║███████╗   ██╔████╔██║██║██╔██╗ ██║██║
 ██║██╔══██╗██║╚════██║   ██║╚██╔╝██║██║██║╚██╗██║██║
 ██║██║  ██║██║███████║   ██║ ╚═╝ ██║██║██║ ╚████║██║
 ╚═╝╚═╝  ╚═╝╚═╝╚══════╝   ╚═╝     ╚═╝╚═╝╚═╝  ╚═══╝╚═╝
\x1b[0m
\x1b[36m [ NEURAL CORE ONLINE ]\x1b[0m
\x1b[35m [ UI PORT ] \x1b[0m http://localhost:${port}
\x1b[35m [ AGENT ]   \x1b[0m Awaiting Connection...
\x1b[90m [ EXIT ]    \x1b[0m Press \x1b[31mCtrl + C\x1b[0m to stop
========================================================
\x1b[36m CREATED BY \x1b[0m Harsh (\x1b[32m@irisxai\x1b[0m)
\x1b[36m GITHUB     \x1b[0m https://github.com/201Harsh
\x1b[36m INSTAGRAM  \x1b[0m https://www.instagram.com/201harshs/
========================================================
`;
    process.stdout.write(banner + "\n");
  });

  if (process.env.NODE_ENV === "production") {
    const __filename = fileURLToPath(import.meta.url);
    const __dirname = path.dirname(__filename);

    app.use(express.static(__dirname));

    app.get(/.*/, (req, res) => {
      res.sendFile(path.join(__dirname, "index.html"));
    });
  } else {
    ViteExpress.bind(app, server);
  }
};

startServer();
