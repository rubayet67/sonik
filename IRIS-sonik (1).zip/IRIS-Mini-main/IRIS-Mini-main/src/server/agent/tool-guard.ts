/**
 * tool-guard.ts
 *
 * A small, pure (no Gemini / socket / audio) validation layer that sits between
 * Gemini function calls and the EXISTING tool handlers in `../tools/*`.
 *
 * It does not execute anything itself. For every function call it decides:
 *   - "run"     : arguments are valid & safe; here are the normalised arguments
 *   - "confirm" : action is potentially destructive; needs the user's spoken OK
 *   - "noop"    : nothing to do (e.g. the folder already exists)
 *   - "reject"  : malformed or not allowed; here is a plain-language reason
 *
 * Why it exists: the existing tools trust their arguments completely
 * (`open(url)` will launch ANY string, `writeFileSync` will overwrite ANY path,
 * `fkill` will kill ANY process incl. this server). Because arguments originate
 * from an LLM that listens to a live microphone, they must be validated.
 */
import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";

export type ToolArgs = Record<string, unknown>;

export interface AppInfo {
  /** Human friendly name used in spoken/UI messages. */
  display: string;
  /** Name handed to the existing `open_app` tool. */
  launch: string;
  /** Candidate process names (no ".exe"), used to close / verify the app. */
  processes: string[];
  /** Closing it is unlikely to lose user work -> no confirmation needed. */
  lowRiskClose: boolean;
  /** Never allow this to be force-closed (e.g. Explorer). */
  closeBlocked: boolean;
  /** Present in the built-in catalog (process names are trustworthy). */
  known: boolean;
}

export type ToolPlan =
  | {
      status: "run";
      name: string;
      args: Record<string, string>;
      summary: string;
      app?: AppInfo;
    }
  | {
      status: "confirm";
      name: string;
      args: Record<string, string>;
      summary: string;
      prompt: string;
    }
  | { status: "noop"; message: string }
  | { status: "reject"; reason: string };

const reject = (reason: string): ToolPlan => ({ status: "reject", reason });

const isRecord = (v: unknown): v is ToolArgs =>
  typeof v === "object" && v !== null && !Array.isArray(v);

/** Returns a trimmed, control-char-free string or null if missing/invalid. */
function strArg(args: ToolArgs, key: string, max: number): string | null {
  const v = args[key];
  if (typeof v !== "string") return null;
  // eslint-disable-next-line no-control-regex
  const s = v.replace(/[\u0000-\u001f\u007f]/g, " ").trim();
  if (s.length === 0 || s.length > max) return null;
  return s;
}

/* -------------------------------------------------------------------------- */
/*  Applications                                                              */
/* -------------------------------------------------------------------------- */

interface CatalogEntry {
  keys: string[];
  display: string;
  launch: string;
  processes: string[];
  lowRiskClose?: boolean;
  closeBlocked?: boolean;
}

/**
 * Friendly-name -> launch / process mapping. `launch` values that already exist
 * in app-agent.ts's own Windows map (calculator, notepad, paint, camera,
 * settings, photos, clock, explorer...) are passed through unchanged so that
 * map keeps doing the work; everything else falls through to the tool's
 * `openApp()` path with a name Windows' Start-Process understands.
 *
 * `processes` fixes close_app: fkill matches the literal process image name,
 * and e.g. the Calculator process is CalculatorApp.exe, not "Calculator".
 */
const CATALOG: CatalogEntry[] = [
  { keys: ["calculator", "calc", "windows calculator"], display: "Calculator", launch: "calculator", processes: ["CalculatorApp", "Calculator"], lowRiskClose: true },
  { keys: ["notepad", "note pad"], display: "Notepad", launch: "notepad", processes: ["Notepad"] },
  { keys: ["paint", "mspaint", "ms paint"], display: "Paint", launch: "paint", processes: ["mspaint"] },
  { keys: ["camera", "windows camera"], display: "Camera", launch: "camera", processes: ["WindowsCamera"], lowRiskClose: true },
  { keys: ["settings", "windows settings"], display: "Settings", launch: "settings", processes: ["SystemSettings"], lowRiskClose: true },
  { keys: ["photos", "windows photos"], display: "Photos", launch: "photos", processes: ["Microsoft.Photos"], lowRiskClose: true },
  { keys: ["clock", "alarms"], display: "Clock", launch: "clock", processes: ["Time"], lowRiskClose: true },
  { keys: ["file explorer", "explorer", "files", "my computer", "this pc"], display: "File Explorer", launch: "explorer", processes: [], closeBlocked: true },
  { keys: ["chrome", "google chrome"], display: "Google Chrome", launch: "chrome", processes: ["chrome"] },
  { keys: ["edge", "microsoft edge"], display: "Microsoft Edge", launch: "msedge", processes: ["msedge"] },
  { keys: ["firefox", "mozilla firefox"], display: "Firefox", launch: "firefox", processes: ["firefox"] },
  { keys: ["brave", "brave browser"], display: "Brave", launch: "brave", processes: ["brave"] },
  { keys: ["vs code", "vscode", "visual studio code", "code"], display: "Visual Studio Code", launch: "code", processes: ["Code"] },
  { keys: ["spotify"], display: "Spotify", launch: "spotify", processes: ["Spotify"], lowRiskClose: true },
  { keys: ["vlc", "vlc media player"], display: "VLC", launch: "vlc", processes: ["vlc"], lowRiskClose: true },
  { keys: ["word", "microsoft word", "ms word"], display: "Microsoft Word", launch: "winword", processes: ["WINWORD"] },
  { keys: ["excel", "microsoft excel", "ms excel"], display: "Microsoft Excel", launch: "excel", processes: ["EXCEL"] },
  { keys: ["powerpoint", "microsoft powerpoint", "ms powerpoint"], display: "Microsoft PowerPoint", launch: "powerpnt", processes: ["POWERPNT"] },
  { keys: ["outlook", "microsoft outlook"], display: "Outlook", launch: "outlook", processes: ["OUTLOOK"] },
];

/** Never launched by voice: shells, script hosts and system-admin tooling. */
const LAUNCH_DENYLIST = new Set([
  "cmd", "powershell", "pwsh", "powershell_ise", "wscript", "cscript", "mshta",
  "regedit", "regedt32", "reg", "diskpart", "format", "bcdedit", "msiexec",
  "rundll32", "regsvr32", "sc", "schtasks", "taskkill", "net", "net1", "netsh",
  "wmic", "certutil", "bitsadmin", "cipher", "takeown", "icacls", "cacls",
  "runas", "vssadmin", "wevtutil", "bash", "sh", "wsl", "mmc", "wt",
  "windowsterminal",
]);

/** Never force-closed by voice: OS-critical processes and this server itself. */
function protectedProcesses(): Set<string> {
  const own = path
    .basename(process.execPath)
    .replace(/\.exe$/i, "")
    .toLowerCase();
  return new Set([
    "system", "system idle process", "idle", "registry", "memcompression",
    "smss", "csrss", "wininit", "winlogon", "services", "lsass", "lsaiso",
    "svchost", "explorer", "dwm", "fontdrvhost", "sihost", "taskhostw",
    "runtimebroker", "ctfmon", "audiodg", "spoolsv", "searchhost",
    "startmenuexperiencehost", "shellexperiencehost", "textinputhost",
    "securityhealthservice", "securityhealthsystray", "msmpeng", "nissrv",
    "wudfhost", "node", "tsx", "nodemon", "npm", "npx", "iris", "iris-mini",
    "cmd", "powershell", "pwsh", "conhost", "windowsterminal", "wt",
    "openconsole", "bash", "wsl", "wslhost", own,
  ]);
}

const SCRIPT_EXTENSIONS = /\.(bat|cmd|ps1|psm1|vbs|vbe|js|jse|wsf|wsh|msi|lnk|reg|hta|scr|com|dll|sys|cpl|inf|pif)$/i;

export function resolveApp(raw: string): { app: AppInfo } | { error: string } {
  let name = raw.trim().replace(/^["']+|["']+$/g, "").replace(/\s+/g, " ");
  name = name.replace(/\.exe$/i, "");
  if (name.length === 0 || name.length > 64) {
    return { error: "Application name is empty or too long." };
  }
  if (!/^[A-Za-z0-9][A-Za-z0-9 ._+-]*$/.test(name)) {
    return {
      error:
        "Application names may only contain English letters, digits, spaces and . _ + - (no paths, quotes or special characters). Use the application's English name.",
    };
  }
  if (SCRIPT_EXTENSIONS.test(name)) {
    return { error: "Script and installer files cannot be launched by voice." };
  }
  if (/^\d+$/.test(name)) {
    return { error: "Applications must be named, not referred to by number." };
  }

  const key = name.toLowerCase();
  const hit = CATALOG.find((c) => c.keys.includes(key));
  if (hit) {
    return {
      app: {
        display: hit.display,
        launch: hit.launch,
        processes: hit.processes,
        lowRiskClose: hit.lowRiskClose === true,
        closeBlocked: hit.closeBlocked === true,
        known: true,
      },
    };
  }
  return {
    app: {
      display: name,
      launch: name,
      processes: [name],
      lowRiskClose: false,
      closeBlocked: false,
      known: false,
    },
  };
}

function planOpenApp(args: ToolArgs): ToolPlan {
  const raw = strArg(args, "app_name", 200);
  if (raw === null) return reject("Missing or invalid 'app_name' (a non-empty string is required).");
  const r = resolveApp(raw);
  if ("error" in r) return reject(r.error);
  const { app } = r;
  const base = app.launch.toLowerCase();
  if (LAUNCH_DENYLIST.has(base) || LAUNCH_DENYLIST.has(app.display.toLowerCase())) {
    return reject(`Opening "${app.display}" by voice is not allowed (shells, script hosts and system-admin tools are blocked).`);
  }
  return {
    status: "run",
    name: "open_app",
    args: { app_name: app.launch },
    summary: `Open ${app.display}`,
    app,
  };
}

function planCloseApp(args: ToolArgs, confirmed: boolean): ToolPlan {
  const raw = strArg(args, "app_name", 200);
  if (raw === null) return reject("Missing or invalid 'app_name' (a non-empty string is required).");
  const r = resolveApp(raw);
  if ("error" in r) return reject(r.error);
  const { app } = r;
  if (app.closeBlocked) {
    return reject(`"${app.display}" is a core part of Windows and cannot be force-closed by voice.`);
  }
  const prot = protectedProcesses();
  const candidates = app.processes.length > 0 ? app.processes : [app.launch];
  for (const p of [...candidates, app.display, app.launch]) {
    if (prot.has(p.toLowerCase())) {
      return reject(`"${app.display}" is a protected system or developer process and cannot be force-closed by voice.`);
    }
  }
  const plan = {
    name: "close_app",
    args: { app_name: candidates[0] },
    summary: `Close ${app.display}`,
    app,
  };
  if (!app.lowRiskClose && !confirmed) {
    return {
      status: "confirm",
      ...plan,
      prompt: `Closing ${app.display} force-quits it, so any unsaved work in it would be lost. Ask the user: "Do you want me to force close ${app.display}?"`,
    };
  }
  return { status: "run", ...plan };
}

/* -------------------------------------------------------------------------- */
/*  Web                                                                       */
/* -------------------------------------------------------------------------- */

function planOpenWebsite(args: ToolArgs): ToolPlan {
  let raw = strArg(args, "url", 2048);
  if (raw === null) return reject("Missing or invalid 'url' (a non-empty string is required).");

  // Backslashes / leading slashes mean a file or network path, not a web address.
  if (raw.includes("\\") || /^\/\//.test(raw)) {
    return reject(`"${raw}" looks like a file or network path, not a web address.`);
  }

  // "localhost:3000" and "example.com:8080" look like URI schemes; treat as host:port.
  if (/^[\w.-]+:\d+(\/|$)/.test(raw) || !/^[a-z][a-z0-9+.-]*:/i.test(raw)) {
    raw = `https://${raw.replace(/^\/+/, "")}`;
    if (/^https:\/\/(localhost|127\.0\.0\.1)(:|\/|$)/i.test(raw)) {
      raw = raw.replace(/^https:/, "http:");
    }
  }

  let url: URL;
  try {
    url = new URL(raw);
  } catch {
    return reject(`"${raw}" is not a valid web address.`);
  }
  if (url.protocol !== "http:" && url.protocol !== "https:") {
    return reject(`Only http and https web addresses can be opened (got "${url.protocol}").`);
  }
  if (!url.hostname) return reject("The web address has no host name.");
  if (url.username || url.password) {
    return reject("Web addresses containing a username or password are not allowed.");
  }
  return {
    status: "run",
    name: "open_website",
    args: { url: url.href },
    summary: `Open ${url.hostname}`,
  };
}

function planSearch(name: "search_google" | "search_youtube", args: ToolArgs): ToolPlan {
  const q = strArg(args, "query", 300);
  if (q === null) return reject("Missing or invalid 'query' (a non-empty string up to 300 characters is required).");
  return {
    status: "run",
    name,
    args: { query: q },
    summary: `${name === "search_google" ? "Google" : "YouTube"} search: ${q}`,
  };
}

/* -------------------------------------------------------------------------- */
/*  File system                                                               */
/* -------------------------------------------------------------------------- */

const MAX_FILE_BYTES = 1024 * 1024;

/** File types that Windows can execute / auto-run. Never written by voice. */
const BLOCKED_WRITE_EXTENSIONS = new Set([
  ".exe", ".dll", ".com", ".scr", ".msi", ".bat", ".cmd", ".ps1", ".psm1",
  ".vbs", ".vbe", ".wsf", ".wsh", ".hta", ".lnk", ".reg", ".jse", ".sys",
  ".cpl", ".inf", ".pif", ".msc", ".gadget",
]);

/** Folders inside the home directory that voice commands must not touch. */
const PROTECTED_SEGMENTS = new Set([
  "appdata", "start menu", "programdata", ".ssh", ".gnupg", ".aws", ".azure",
  ".kube", ".config", ".git", "ntuser.dat",
]);

export interface KnownFolders {
  home: string;
  desktop: string;
  documents: string;
  downloads: string;
}

function firstExisting(candidates: string[], fallback: string): string {
  for (const c of candidates) {
    try {
      if (c && fs.statSync(c).isDirectory()) return c;
    } catch {
      /* try next */
    }
  }
  return fallback;
}

/** Resolves Desktop/Documents/Downloads, including OneDrive-redirected ones. */
export function getKnownFolders(): KnownFolders {
  const home = os.homedir();
  const oneDrives = [
    process.env.OneDrive,
    process.env.OneDriveConsumer,
    process.env.OneDriveCommercial,
    path.join(home, "OneDrive"),
  ].filter((v): v is string => typeof v === "string" && v.length > 0);

  const pick = (name: string) =>
    firstExisting(
      [path.join(home, name), ...oneDrives.map((o) => path.join(o, name))],
      path.join(home, name),
    );
  return {
    home,
    desktop: pick("Desktop"),
    documents: pick("Documents"),
    downloads: pick("Downloads"),
  };
}

/** Home directory plus anything listed in IRIS_ALLOWED_DIRS. */
export function getAllowedRoots(): string[] {
  const extra = (process.env.IRIS_ALLOWED_DIRS ?? "")
    .split(path.delimiter)
    .map((s) => s.trim())
    .filter(Boolean)
    .map((s) => path.resolve(s));
  return [os.homedir(), ...extra];
}

// --- pure, platform-independent string checks (unit-testable anywhere) ------

export const isUncOrDevicePath = (p: string): boolean => /^[\\/]{2}/.test(p);

/** "C:\x" is fine; any other ":" is an NTFS alternate data stream or invalid. */
export const hasAltStream = (p: string): boolean =>
  p.replace(/^[a-zA-Z]:(?=[\\/]|$)/, "").includes(":");

export const hasReservedWindowsName = (p: string): boolean =>
  p
    .split(/[\\/]+/)
    .some(
      (seg) =>
        /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(\..*)?$/i.test(seg) ||
        (seg.length > 1 && /[. ]$/.test(seg) && seg !== ".."),
    );

function isInside(child: string, root: string): boolean {
  const rel = path.relative(root, child);
  return rel === "" || (!rel.startsWith("..") && !path.isAbsolute(rel));
}

/** Nearest existing ancestor's real path must still be inside an allowed root (blocks symlink/junction escapes). */
function realPathContained(target: string, roots: string[]): boolean {
  let probe = target;
  while (!fs.existsSync(probe)) {
    const up = path.dirname(probe);
    if (up === probe) break;
    probe = up;
  }
  let real: string;
  try {
    real = fs.realpathSync.native(probe);
  } catch {
    return false;
  }
  return roots.some((r) => {
    let rr = r;
    try {
      rr = fs.realpathSync.native(r);
    } catch {
      /* use unresolved root */
    }
    return isInside(real, rr);
  });
}

export function resolveUserPath(
  input: string,
): { ok: true; path: string } | { ok: false; reason: string } {
  const bad = (reason: string) => ({ ok: false as const, reason });
  let p = input.trim().replace(/^["']+|["']+$/g, "");
  if (p.length === 0) return bad("The path is empty.");
  if (p.length > 400) return bad("The path is too long.");
  // eslint-disable-next-line no-control-regex
  if (/[\u0000-\u001f<>"|?*]/.test(p)) return bad("The path contains characters that are not allowed.");
  if (isUncOrDevicePath(p)) return bad("Network (UNC) and device paths are not allowed.");
  if (hasAltStream(p)) return bad("Paths containing ':' (other than a drive letter) are not allowed.");
  if (/^[a-zA-Z]:(?![\\/])/.test(p)) return bad("Drive-relative paths are not allowed; use a full path.");

  const folders = getKnownFolders();

  p = p.replace(/^%userprofile%(?=[\\/]|$)/i, folders.home);
  if (p === "~" || /^~[\\/]/.test(p)) p = path.join(folders.home, p.slice(1));

  if (!path.isAbsolute(p)) {
    // Relative paths: honour a leading Desktop/Documents/Downloads/Home alias,
    // otherwise default to the Desktop so results are easy for the user to find.
    const parts = p.split(/[\\/]+/).filter(Boolean);
    const alias = (parts[0] ?? "").toLowerCase().replace(/^(my|the) /, "");
    const map: Record<string, string> = {
      desktop: folders.desktop,
      documents: folders.documents,
      document: folders.documents,
      downloads: folders.downloads,
      download: folders.downloads,
      home: folders.home,
    };
    if (map[alias]) p = path.join(map[alias], ...parts.slice(1));
    else p = path.join(folders.desktop, ...parts);
  }

  const abs = path.resolve(p);
  if (hasReservedWindowsName(abs.replace(/^[a-zA-Z]:/, ""))) {
    return bad("The path contains a reserved or invalid Windows name.");
  }

  const roots = getAllowedRoots();
  const root = roots.find((r) => isInside(abs, r));
  if (!root) {
    return bad(
      `Voice commands may only create files inside your home folder (${folders.home}). That location is not allowed.`,
    );
  }
  const segments = path.relative(root, abs).split(/[\\/]+/).filter(Boolean);
  const hit = segments.find((s) => PROTECTED_SEGMENTS.has(s.toLowerCase()));
  if (hit) return bad(`The "${hit}" folder is protected and cannot be modified by voice.`);
  if (!realPathContained(abs, roots)) {
    return bad("That path resolves outside the allowed folders (symbolic link or junction).");
  }
  return { ok: true, path: abs };
}

function planCreateDirectory(args: ToolArgs): ToolPlan {
  const raw = strArg(args, "dir_path", 400);
  if (raw === null) return reject("Missing or invalid 'dir_path' (a non-empty string is required).");
  const r = resolveUserPath(raw);
  if (!r.ok) return reject(r.reason);
  try {
    const st = fs.statSync(r.path);
    if (st.isDirectory()) return { status: "noop", message: `The folder already exists at ${r.path}.` };
    return reject(`A file (not a folder) already exists at ${r.path}.`);
  } catch {
    /* does not exist: good */
  }
  return {
    status: "run",
    name: "create_directory",
    args: { dir_path: r.path },
    summary: `Create folder ${r.path}`,
  };
}

function planWriteFile(args: ToolArgs, confirmed: boolean): ToolPlan {
  const raw = strArg(args, "file_path", 400);
  if (raw === null) return reject("Missing or invalid 'file_path' (a non-empty string is required).");
  const content = args.content;
  if (typeof content !== "string") return reject("Missing or invalid 'content' (a string is required; use an empty string for an empty file).");
  if (Buffer.byteLength(content, "utf8") > MAX_FILE_BYTES) {
    return reject("The content is larger than 1 MB, which is more than can be written by voice.");
  }
  const r = resolveUserPath(raw);
  if (!r.ok) return reject(r.reason);

  const ext = path.extname(r.path).toLowerCase();
  if (BLOCKED_WRITE_EXTENSIONS.has(ext)) {
    return reject(`Files of type "${ext}" can run code on Windows and cannot be created by voice.`);
  }

  let exists = false;
  try {
    const st = fs.statSync(r.path);
    if (st.isDirectory()) return reject(`${r.path} is a folder, not a file.`);
    exists = true;
  } catch {
    /* new file */
  }

  const plan = {
    name: "write_file",
    args: { file_path: r.path, content },
    summary: `Write file ${r.path}`,
  };
  if (exists && !confirmed) {
    return {
      status: "confirm",
      ...plan,
      prompt: `A file already exists at ${r.path}. Writing would permanently overwrite it. Ask the user: "That file already exists. Should I overwrite it?"`,
    };
  }
  return { status: "run", ...plan };
}

/* -------------------------------------------------------------------------- */
/*  Public entry point                                                        */
/* -------------------------------------------------------------------------- */

export function planToolCall(
  name: string,
  rawArgs: unknown,
  opts: { confirmed?: boolean } = {},
): ToolPlan {
  if (rawArgs !== undefined && rawArgs !== null && !isRecord(rawArgs)) {
    return reject("Malformed function call: arguments must be an object.");
  }
  const args: ToolArgs = isRecord(rawArgs) ? rawArgs : {};
  const confirmed = opts.confirmed === true;
  switch (name) {
    case "open_app":
      return planOpenApp(args);
    case "close_app":
      return planCloseApp(args, confirmed);
    case "open_website":
      return planOpenWebsite(args);
    case "search_google":
    case "search_youtube":
      return planSearch(name, args);
    case "create_directory":
      return planCreateDirectory(args);
    case "write_file":
      return planWriteFile(args, confirmed);
    default:
      return reject(`No safety policy is defined for tool "${name}", so it was not run.`);
  }
}

/* -------------------------------------------------------------------------- */
/*  Spoken confirmation                                                       */
/* -------------------------------------------------------------------------- */

const AFFIRM =
  /(^|[^\p{L}])(yes|yeah|yep|yup|sure|ok|okay|confirm|confirmed|go ahead|do it|proceed|affirmative|please do|haan|han|ji|হ্যাঁ|হ্যা|হাঁ|हाँ|हां|हा|जी|ठीक है)([^\p{L}]|$)/iu;
const NEGATE =
  /(^|[^\p{L}])(no|nope|nah|don'?t|do not|cancel|stop|wait|never ?mind|negative|nahi|na|না|नहीं|नही|मत)([^\p{L}]|$)/iu;

/** True when a user utterance clearly says "yes" and nothing that says "no". */
export function classifyReply(text: string): "yes" | "no" | "unclear" {
  if (NEGATE.test(text)) return "no";
  if (AFFIRM.test(text)) return "yes";
  return "unclear";
}

/** Parses `tasklist /FO CSV /NH` output into lowercase image names. */
export function parseTasklistCsv(stdout: string): string[] {
  return stdout
    .split(/\r?\n/)
    .map((l) => /^"([^"]+)"/.exec(l)?.[1]?.toLowerCase())
    .filter((v): v is string => typeof v === "string");
}
